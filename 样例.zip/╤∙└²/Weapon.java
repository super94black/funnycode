package lesson.work;

/**
 * @Author zhang
 * @Date 2017/11/9 15:52
 * @Content 武器类
 */
public class Weapon {
    private String weaponName;
    private int weaponAttact;

    public String getWeaponName() {
        return weaponName;
    }

    public void setWeaponName(String weaponName) {
        this.weaponName = weaponName;
    }

    public int getWeaponAttact() {
        return weaponAttact;
    }

    public void setWeaponAttact(int weaponAttact) {
        this.weaponAttact = weaponAttact;
    }
}
